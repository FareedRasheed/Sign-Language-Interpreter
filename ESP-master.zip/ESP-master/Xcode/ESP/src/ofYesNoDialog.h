#include <string>

using namespace std;

bool ofSystemYesNoDialog(string title="Alert",string message="");