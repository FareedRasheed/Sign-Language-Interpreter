#include "user.h"

// This is a hack.
// Otherwise, we will need to create a target for each user application.
//#include "examples/user_audio_beat_detection.cpp"
//#include "examples/user_color_sensor.cpp"
#include "examples/user_accelerometer_gestures.cpp"
//#include "examples/user_accelerometer_gestures_simple.cpp"
//#include "examples/user_accelerometer_gestures_osc.cpp"
//#include "examples/user_accelerometer_poses.cpp"
//#include "examples/user_accelerometer_walk_detection.cpp"
//#include "examples/user_capacitive_sensing.cpp"
//#include "examples/user_speech_detection.cpp"
//#include "examples/user_speaker.cpp"
//#include "examples/user_sudden_motion.cpp"
//#include "examples/user_touche.cpp"
